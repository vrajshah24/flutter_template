// import 'package:flutter/animation.dart';
// import 'package:flutter/material.dart';

// Color subprimaryColor = Color(0xffEC1D25).withOpacity(0.5);
// Color primaryColor = Color(0xffEC1D25);
// Color secondaryColor = Colors.white;
// Color descColor = Color(0xff212529);
// Color subtitle = Color(0xff495057);
// Color backgroundColor = Color(0xffF8F9FA);