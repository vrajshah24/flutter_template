// import 'package:try_app/database/local/tables.dart';

// String createTableforUser= "Create table if not exists $userTable(id INTEGER ,name TEXT ,mobile TEXT,dob TEXT,address TEXT,PRIMARY KEY(id AUTOINCREMENT))";
