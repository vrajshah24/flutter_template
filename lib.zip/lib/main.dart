import 'package:flutter/material.dart';

import 'widgets/splashscreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MaterialApp(
    routes: {
      '/': (context) => const SplashScreen(),
    },
  ));
}
